<template>
    <div id="app">
        <SnakeGame v-model="test" :pairs.sync="xxx" :test.sync="xxx"/>
    </div>
</template>

<script>
import SnakeGame from "./components/SnakeGame.vue";

export default {
    name: "App",
    components: {
        SnakeGame
    },
    data() {
        return {
            test: 0,
            xxx: 0
        };
    }
};
</script>

<style>
  html {
    background-color: #2b313b;
  }
</style>
